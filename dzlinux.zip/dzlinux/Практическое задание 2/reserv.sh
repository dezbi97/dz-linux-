#!/bin/bash

tar -cvpf /archive/bc_file.tar /home /var/log /etc/vsftpd.conf /etc/ssh/sshd_config /etc/xrdp


