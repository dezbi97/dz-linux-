#!/bin/bash

$ curl ifconfig.co

if ping -c 2 8.8.8.8
then echo "интернет есть"
else echo "интернета нет"
fi

wget https://browser.yandex.ru/download/?banerid=6302000000&zih=1&beta=1&os=linux&x64=1&package=deb&full=1

if [[ `cat /etc/apt/sources.list | grep "backports"` ]];
then echo Backports DONE
else echo Backports FAIL

fi

sudo apt update

sudo apt install apache2
sudo systemctl enable apache2

sudo apt install python3.9

sudo apt install sshd


curl -4 wttr.in/Astrakhan

wget -O - http://www.reddit.com/r/wallpaper |\
    grep -Eo 'http://i.imgur.com[^&]+jpg' |\
    shuf -n 1 |\
    xargs wget -O background.jpg
feh --bg-fill background.jpg
